package com.durga;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hellocontrol {
	@GetMapping(path="/")
	public String hello() {
		return "<h1>hello world</h1>";
	}

}
